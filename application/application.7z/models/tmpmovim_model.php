<?php
/**
 * Description of tmpmovim
 *
 * @author dnl
 */
class Tmpmovim_model extends MY_Model{
  function __construct() {
    parent::__construct();
    $this->setTable('tmpmovim');
  }
}
