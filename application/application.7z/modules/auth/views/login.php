<div class="box">
  <?php echo Template::block('formulario');?>
</div>
<script>
$(document).ready(function(){
  $('form').css('background-color', '#F79C1A');
});
</script>