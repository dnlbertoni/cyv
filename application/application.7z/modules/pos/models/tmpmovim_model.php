<?php
/**
 * Description of tmpmovim
 *
 * @author dnl
 */
class Tmpmovim_model extends MY_Model{
  function __construct() {
    parent::__construct();
    $this->setTable('tmpmovim');
  }
  function getDetalle($puesto){
    $this->db->select('cantidad');
    $this->db->select('articulo as articulo_id');
    $this->db->select('articulos.nombre as articulo_nombre');
    $this->db->select('articulos.precio as articulo_precio');
    $this->db->select('articulos.precio * cantidad as importe');
    $this->db->from($this->getTable());
    $this->db->join('articulos', 'articulo=articulos.id', 'inner');
    $this->db->where('puesto', $puesto);
    return $this->db->get()->result();
  }
}
